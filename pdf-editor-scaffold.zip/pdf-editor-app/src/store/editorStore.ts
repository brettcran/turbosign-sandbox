import { create } from 'zustand';

export type EditorElement = {
  id: string;
  type: 'text' | 'check' | 'x' | 'circle' | 'image';
  content: string;
  x: number;
  y: number;
  pageNumber: number;
  fontSize?: number;
  color?: string;
  rotation?: number;
};

type EditorStore = {
  elements: EditorElement[];
  selectedIds: string[];
  addElement: (el: EditorElement) => void;
  updateElementPosition: (id: string, x: number, y: number) => void;
  updateElementContent: (id: string, content: string) => void;
  updateElementStyle: (id: string, style: Partial<EditorElement>) => void;
  updateElementRotation: (id: string, angle: number) => void;
  deleteElement: (id: string) => void;
  setSelectedIds: (ids: string[]) => void;
  toggleSelectedId: (id: string) => void;
  clearSelection: () => void;
  undo: () => void;
  redo: () => void;
  history: EditorElement[][];
  redoStack: EditorElement[][];
  setElements: (els: EditorElement[]) => void;
};

export const useEditorStore = create<EditorStore>((set, get) => ({
  elements: [],
  selectedIds: [],
  history: [],
  redoStack: [],
  addElement: (el) => {
    const prev = get().elements;
    set({
      elements: [...prev, el],
      history: [...get().history, prev],
      redoStack: [],
    });
  },
  updateElementPosition: (id, x, y) => {
    const updated = get().elements.map(el => el.id === id ? { ...el, x, y } : el);
    set({ elements: updated, history: [...get().history, get().elements], redoStack: [] });
  },
  updateElementContent: (id, content) => {
    const updated = get().elements.map(el => el.id === id ? { ...el, content } : el);
    set({ elements: updated, history: [...get().history, get().elements], redoStack: [] });
  },
  updateElementStyle: (id, style) => {
    const updated = get().elements.map(el => el.id === id ? { ...el, ...style } : el);
    set({ elements: updated, history: [...get().history, get().elements], redoStack: [] });
  },
  updateElementRotation: (id, angle) => {
    const updated = get().elements.map(el => el.id === id ? { ...el, rotation: angle } : el);
    set({ elements: updated, history: [...get().history, get().elements], redoStack: [] });
  },
  deleteElement: (id) => {
    const filtered = get().elements.filter(el => el.id !== id);
    set({ elements: filtered, history: [...get().history, get().elements], redoStack: [] });
  },
  setSelectedIds: (ids) => set({ selectedIds: ids }),
  toggleSelectedId: (id) =>
    set((state) => ({
      selectedIds: state.selectedIds.includes(id)
        ? state.selectedIds.filter(i => i !== id)
        : [...state.selectedIds, id],
    })),
  clearSelection: () => set({ selectedIds: [] }),
  undo: () => {
    const history = get().history;
    if (!history.length) return;
    const last = history[history.length - 1];
    set({
      elements: last,
      history: history.slice(0, -1),
      redoStack: [get().elements, ...get().redoStack],
    });
  },
  redo: () => {
    const redo = get().redoStack;
    if (!redo.length) return;
    const next = redo[0];
    set({
      elements: next,
      history: [...get().history, get().elements],
      redoStack: redo.slice(1),
    });
  },
  setElements: (els) => set({ elements: els, history: [], redoStack: [] }),
}));