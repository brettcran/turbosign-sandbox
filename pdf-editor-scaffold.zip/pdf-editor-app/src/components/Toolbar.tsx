import React from 'react';
import { useEditorStore } from '../store/editorStore';
import { v4 as uuidv4 } from 'uuid';

export const Toolbar: React.FC<{ file: File; zoom: number; setZoom: (z: number) => void }> = ({ file, zoom, setZoom }) => {
  const { addElement, elements, selectedIds, deleteElement, undo, redo } = useEditorStore();

  const handleAdd = (type: 'text' | 'check' | 'x' | 'circle') => {
    addElement({
      id: uuidv4(),
      type,
      content: type === 'text' ? 'Edit me' : type === 'check' ? '✔' : type === 'x' ? '❌' : '⭕',
      x: 100,
      y: 100,
      pageNumber: 1,
      fontSize: 18,
      color: '#000000',
    });
  };

  return (
    <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
      <button onClick={() => handleAdd('text')}>Text</button>
      <button onClick={() => handleAdd('check')}>✔</button>
      <button onClick={() => handleAdd('x')}>❌</button>
      <button onClick={() => handleAdd('circle')}>⭕</button>
      <button onClick={undo}>Undo</button>
      <button onClick={redo}>Redo</button>
      <button onClick={() => selectedIds.forEach(deleteElement)}>Delete</button>
      <button onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}>-</button>
      <button onClick={() => setZoom(Math.min(2, zoom + 0.1))}>+</button>
      <span>{Math.round(zoom * 100)}%</span>
    </div>
  );
};