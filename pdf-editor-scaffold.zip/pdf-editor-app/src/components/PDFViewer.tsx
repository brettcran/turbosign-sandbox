import React, { useState } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { EditorOverlay } from './EditorOverlay';

pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.js`;

type Props = {
  file: File;
  zoom: number;
};

export const PDFViewer: React.FC<Props> = ({ file, zoom }) => {
  const [numPages, setNumPages] = useState<number>(0);
  const [pageSizes, setPageSizes] = useState<{ width: number; height: number }[]>([]);

  const onLoadSuccess = ({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
  };

  const handleRender = (index: number, page: any) => {
    const { width, height } = page.getViewport({ scale: 1 });
    setPageSizes(prev => {
      const copy = [...prev];
      copy[index] = { width, height };
      return copy;
    });
  };

  return (
    <Document file={file} onLoadSuccess={onLoadSuccess}>
      {Array.from({ length: numPages }, (_, idx) => (
        <div key={idx} style={{ position: 'relative', marginBottom: 20 }}>
          <Page
            pageNumber={idx + 1}
            scale={zoom}
            onRenderSuccess={(page) => handleRender(idx, page)}
          />
          {pageSizes[idx] && (
            <EditorOverlay
              pageNumber={idx + 1}
              zoom={zoom}
              width={pageSizes[idx].width}
              height={pageSizes[idx].height}
            />
          )}
        </div>
      ))}
    </Document>
  );
};