import React, { useState, useRef, useEffect } from 'react';
import { useEditorStore } from '../store/editorStore';

type Props = {
  pageNumber: number;
  zoom: number;
  width: number;
  height: number;
};

export const EditorOverlay: React.FC<Props> = ({ pageNumber, zoom, width, height }) => {
  const {
    elements,
    updateElementPosition,
    updateElementContent,
    updateElementStyle,
    updateElementRotation,
    selectedIds,
    toggleSelectedId,
    setSelectedIds,
  } = useEditorStore();

  const [draggingId, setDraggingId] = useState<string | null>(null);
  const [offset, setOffset] = useState({ x: 0, y: 0 });

  const pageElements = elements.filter(el => el.pageNumber === pageNumber);

  const handleMouseDown = (e: React.MouseEvent, id: string) => {
    const el = pageElements.find(el => el.id === id);
    if (!el) return;
    if (e.shiftKey) toggleSelectedId(id);
    else setSelectedIds([id]);
    setDraggingId(id);
    setOffset({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!draggingId) return;
    const dx = (e.clientX - offset.x);
    const dy = (e.clientY - offset.y);
    setOffset({ x: e.clientX, y: e.clientY });

    const movingIds = selectedIds.includes(draggingId) ? selectedIds : [draggingId];
    movingIds.forEach(id => {
      const el = elements.find(e => e.id === id);
      if (el) updateElementPosition(id, el.x + dx / zoom, el.y + dy / zoom);
    });
  };

  const handleMouseUp = () => {
    setDraggingId(null);
  };

  return (
    <div
      style={{
        position: 'absolute',
        top: 0,
        left: 0,
        width: `${width * zoom}px`,
        height: `${height * zoom}px`,
        transform: `scale(${zoom})`,
        transformOrigin: 'top left',
        pointerEvents: 'auto',
      }}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
    >
      {pageElements.map(el => (
        <div
          key={el.id}
          onMouseDown={(e) => handleMouseDown(e, el.id)}
          style={{
            position: 'absolute',
            left: el.x,
            top: el.y,
            fontSize: el.fontSize ?? 18,
            color: el.color ?? '#000',
            transform: `rotate(${el.rotation ?? 0}deg)`,
            userSelect: 'none',
            pointerEvents: 'auto',
            border: selectedIds.includes(el.id) ? '1px dashed blue' : 'none',
          }}
        >
          {el.type === 'image' ? (
            <img src={el.content} alt="" style={{ width: el.fontSize ?? 100 }} />
          ) : (
            el.content
          )}
        </div>
      ))}
    </div>
  );
};