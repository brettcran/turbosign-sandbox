import React, { useRef, useState } from 'react';

export const SignaturePadModal: React.FC<{ onSave: (dataUrl: string) => void; onClose: () => void }> = ({ onSave, onClose }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [sigName, setSigName] = useState('');

  const handleSave = () => {
    const canvas = canvasRef.current;
    if (!canvas || !sigName) return;
    const dataUrl = canvas.toDataURL('image/png');
    const sigs = JSON.parse(localStorage.getItem('saved_signatures') || '[]');
    sigs.push({ name: sigName, dataUrl });
    localStorage.setItem('saved_signatures', JSON.stringify(sigs));
    onSave(dataUrl);
    onClose();
  };

  const clearCanvas = () => {
    const ctx = canvasRef.current?.getContext('2d');
    ctx?.clearRect(0, 0, 400, 200);
  };

  return (
    <div style={{ padding: 20, background: 'white', border: '1px solid #ccc' }}>
      <h4>Draw Signature</h4>
      <canvas
        ref={canvasRef}
        width={400}
        height={200}
        style={{ border: '1px solid black', touchAction: 'none' }}
        onPointerDown={(e) => {
          const ctx = canvasRef.current?.getContext('2d');
          ctx?.beginPath();
          ctx?.moveTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
          canvasRef.current?.setPointerCapture(e.pointerId);
        }}
        onPointerMove={(e) => {
          if (e.buttons !== 1) return;
          const ctx = canvasRef.current?.getContext('2d');
          ctx?.lineTo(e.nativeEvent.offsetX, e.nativeEvent.offsetY);
          ctx?.stroke();
        }}
      />
      <input value={sigName} onChange={(e) => setSigName(e.target.value)} placeholder="Signature name" />
      <div>
        <button onClick={handleSave}>Save</button>
        <button onClick={clearCanvas}>Clear</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
};