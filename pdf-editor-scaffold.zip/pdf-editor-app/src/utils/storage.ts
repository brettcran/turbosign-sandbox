import { set, get, del, keys } from 'idb-keyval';

export const saveProjectToLocal = async (key: string, data: any) => {
  await set(key, data);
};

export const loadProjectFromLocal = async (key: string) => {
  return await get(key);
};

export const deleteProjectFromLocal = async (key: string) => {
  await del(key);
};

export const listSavedProjects = async () => {
  return await keys();
};