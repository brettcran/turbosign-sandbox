import { PDFDocument, rgb, degrees } from 'pdf-lib';
import { EditorElement } from '../store/editorStore';

function hexToRgb(hex: string): [number, number, number] {
  const raw = hex.replace('#', '');
  const bigint = parseInt(raw, 16);
  return [(bigint >> 16) & 255, (bigint >> 8) & 255, bigint & 255];
}

export async function exportPdfWithElements(file: File, elements: EditorElement[]) {
  const buffer = await file.arrayBuffer();
  const pdfDoc = await PDFDocument.load(buffer);
  const pages = pdfDoc.getPages();

  for (const el of elements) {
    const page = pages[el.pageNumber - 1];
    const [r, g, b] = hexToRgb(el.color ?? '#000000');
    const fontSize = el.fontSize ?? 18;
    const rotate = degrees(el.rotation ?? 0);

    if (el.type === 'image') {
      const png = await pdfDoc.embedPng(el.content);
      const dims = png.scale(fontSize / 100);
      page.drawImage(png, {
        x: el.x,
        y: page.getHeight() - el.y,
        width: dims.width,
        height: dims.height,
        rotate,
      });
    } else {
      page.drawText(el.content, {
        x: el.x,
        y: page.getHeight() - el.y,
        size: fontSize,
        color: rgb(r / 255, g / 255, b / 255),
        rotate,
      });
    }
  }

  return await pdfDoc.save();
}